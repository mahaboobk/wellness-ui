import React from 'react'
// ClientList Component
const ClientList = React.memo(({ clients, loading, error }) => {
    const [search, setSearch] = React.useState('');
    return (
        <div className="card">
            <div className="form-group">
                <label htmlFor="search">Search Clients:</label>
                <input
                    type="text"
                    placeholder="Search by name"
                    value={search}
                    onChange={e => setSearch(e.target.value)}
                    style={{ marginBottom: '1rem', width: '100%' }}
                />
            </div>
            <h2>Client List</h2>
            {loading && <p>Loading clients...</p>}
            {error && <p className="error">Error: {error}</p>}
            {!loading && !error && clients.length === 0 && <p>No clients found.</p>}
            {!loading && !error && clients.length > 0 && (
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                        </tr>
                    </thead>
                    <tbody>
                        {clients.filter(client => client.name.toLowerCase().includes(search.toLowerCase())).map(client => (
                            <tr key={client.id}>
                                <td>{client.name}</td>
                                <td>{client.email}</td>
                                <td>{client.phone}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    );
});
export default ClientList;