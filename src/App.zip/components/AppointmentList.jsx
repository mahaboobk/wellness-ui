import React, { useState } from 'react';
// AppointmentList Component
const AppointmentList = React.memo(({ allClients, appointments, loadingAppointments, errorAppointments, onEdit, onDelete }) => {
    const [deletingId, setDeletingId] = useState(null);
    const [selectedClientId, setSelectedClientId] = useState('');
    const clientMap = new Map(allClients.map(client => [client.id, client.name]));
    // Filter appointments based on selected client and upcoming status
    const filteredAppointments = appointments.filter(appt => {
        const isUpcoming = new Date(appt.time) >= new Date();
        const matchesClient = selectedClientId === '' || appt.client_id === parseInt(selectedClientId);
        return isUpcoming && matchesClient;
    });

    return (
        <div className="card">
            <h2>Upcoming Appointments</h2>
            <div className="form-group">
                <label htmlFor="client-filter">Filter by Client:</label>
                <select
                    id="client-filter"
                    value={selectedClientId}
                    onChange={(e) => setSelectedClientId(e.target.value)}
                >
                    <option value="">All Clients</option>
                    {allClients.map(client => (
                        <option key={client.id} value={client.id}>
                            {client.name}
                        </option>
                    ))}
                </select>
            </div>

            {loadingAppointments && <p>Loading appointments...</p>}
            {errorAppointments && <p className="error">Error: {errorAppointments}</p>}
            {!loadingAppointments && !errorAppointments && filteredAppointments.length === 0 && <p>No upcoming appointments found for the selected criteria.</p>}
            {!loadingAppointments && !errorAppointments && filteredAppointments.length > 0 && (
                <table>
                    <thead>
                        <tr>
                            <th>Client</th>
                            <th>Time</th>
                            <th>Actions</th>
                        </tr>
                    </thead><tbody>
                        {filteredAppointments.map(appt => (
                            <tr key={appt.id}>
                                <td>{clientMap.get(appt.client_id)}</td>
                                <td>{new Date(appt.time).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}</td>
                                <td>
                                    <button onClick={() => onEdit(appt)} className="action-button edit-button">Edit</button>
                                    <button
                                        className="action-button delete-button"
                                        onClick={() => onDelete(appt.id)}
                                        disabled={deletingId === appt.id}
                                    >
                                        {deletingId === appt.id ? 'Deleting...' : 'Delete'}
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    );
});

export default AppointmentList;