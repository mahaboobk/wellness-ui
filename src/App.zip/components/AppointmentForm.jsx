import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { postAppointment, updateAppointment } from '../api/wellness-api.js';
// AppointmentForm Component
const AppointmentForm = React.memo(({ clients, editingAppointment, setEditingAppointment }) => {
  const [clientId, setClientId] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState(''); // 'success' or 'error'

  useEffect(() => {
    if (editingAppointment) {
      setClientId(editingAppointment.client_id);
      const apptDate = new Date(editingAppointment.time);
      setDate(apptDate.toISOString().split('T')[0]);
      setTime(apptDate.toTimeString().slice(0, 5));
      setMessage('');
    } else {
      setClientId('');
      setDate('');
      setTime('');
      setMessage('');
    }
  }, [editingAppointment]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');

    if (!clientId || !date || !time) {
      setMessage('Please fill in all required fields (Client, Date, Time).');
      setMessageType('error');
      return;
    }

    try {
      const dateTimeISO = new Date(`${date}T${time}`).toISOString();
      const appointmentPayload = {
        client_id: parseInt(clientId),
        time: dateTimeISO,
      };

      let response;
      if (editingAppointment) {
        response = await updateAppointment(editingAppointment.id, appointmentPayload);
        setMessage("Appointment updated successfully.");
        setMessageType('success');
      } else {
        response = await postAppointment(appointmentPayload);
        setMessage("Appointment booked successfully.");
        setMessageType('success');
      }

      if (response) {
        setClientId('');
        setDate('');
        setTime('');
        setEditingAppointment(null); // Clear editing state
      } else {
        setMessage(response.message || 'Failed to process appointment.');
        setMessageType('error');
      }
    } catch (err) {
      setMessage(err.message || 'An error occurred while processing appointment.');
      setMessageType('error');
      console.error('Appointment form error:', err);
    }
  };

  const getTodayDate = () => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  return (
    <div className="card">
      <h2>{editingAppointment ? 'Edit Appointment' : 'Book New Appointment'}</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="client-select">Client:</label>
          <select
            id="client-select"
            value={clientId}
            onChange={(e) => setClientId(e.target.value)}
            required
            disabled={!!editingAppointment} // Disable client selection when editing
          >
            <option value="">Select a client</option>
            {clients.map(client => (
              <option key={client.id} value={client.id}>
                {client.name}
              </option>
            ))}
          </select>
        </div>
        <div className="form-group-inline">
          <div className="form-group-half">
            <label htmlFor="appointment-date">Date:</label>
            <input
              type="date"
              id="appointment-date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              min={getTodayDate()}
              required
            />
          </div>
          <div className="form-group-half">
            <label htmlFor="appointment-time">Time:</label>
            <input
              type="time"
              id="appointment-time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              required
            />
          </div>
        </div>
        <button type="submit" className="button">
          {editingAppointment ? 'Update Appointment' : 'Schedule Appointment'}
        </button>
        {editingAppointment && (
          <button type="button" onClick={() => setEditingAppointment(null)} className="button cancel-button">
            Cancel Edit
          </button>
        )}
      </form>
      {message && <p className={`message ${messageType}`}>{message}</p>}
    </div>
  );
});

export default AppointmentForm;
