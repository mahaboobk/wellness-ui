import React, { useState, useEffect, useCallback } from 'react';
import { getClients, getAppointments, deleteAppointment, updateAppointment } from './api/wellness-api.js';
import AppointmentForm from './components/AppointmentForm.jsx';
import ClientList from './components/ClientList.jsx';
import AppointmentList from './components/AppointmentList.jsx';

import './App.css';
// Main App Component
const App = () => {
    const [clients, setClients] = useState([]);
    const [appointments, setAppointments] = useState([]);
    const [loadingClients, setLoadingClients] = useState(true);
    const [errorClients, setErrorClients] = useState(null);
    const [loadingAppointments, setLoadingAppointments] = useState(true);
    const [errorAppointments, setErrorAppointments] = useState(null);
    const [editingAppointment, setEditingAppointment] = useState(null);
    // Fetch clients data
    const fetchClients = useCallback(async () => {
        setLoadingClients(true);
        setErrorClients(null);
        try {
            const response = await getClients();
            console.log('Fetched clients:', response);
            if (response.status === 200) {
                setClients(response.data);
            } else {
                setErrorClients('Failed to fetch clients.');
            }
        } catch (err) {
            setErrorClients('Network error fetching clients.');
            console.error('Fetch clients error:', err);
        } finally {
            setLoadingClients(false);
        }
    }, []);

    // Fetch ALL appointments data
    const fetchAllAppointments = useCallback(async () => {
        setLoadingAppointments(true);
        setErrorAppointments(null);
        try {
            const response = await getAppointments();
            response && setAppointments(response);
        } catch (err) {
            setErrorAppointments('Network error fetching all appointments.');
            console.error('Fetch all appointments error:', err);
        } finally {
            setLoadingAppointments(false);
        }
    }, []);

    // Handle appointment deletion
    const handleDeleteAppointment = useCallback(async (id) => {
        if (window.confirm("Are you sure you want to delete this appointment?")) {
            try {
                const response = await deleteAppointment(id);
                console.log('Delete response:', response);
                if (response.status === 204) {
                    console.log('Appointment deleted successfully.');

                    fetchAllAppointments(); // Refresh list after deletion
                } else {
                    console.error(response.message || 'Failed to delete appointment.');
                }
            } catch (err) {
                console.error('Error deleting appointment:', err.message || err);
            }
        }
    }, [fetchAllAppointments]);

    // Initial data fetch on component mount for both clients and all appointments
    useEffect(() => {
        console.log('Fetching initial data...');
        fetchClients();
        fetchAllAppointments();
        console.log('Finished loading data...');
    }, [fetchClients, fetchAllAppointments]);

    // Removed periodic sync as per request

    const handleScheduleSuccess = useCallback(() => {
        console.log('Appointment scheduled/updated. Re-fetching all appointments for update.');
        fetchAllAppointments(); // Re-fetch all appointments to update the list
    }, [fetchAllAppointments]);

    const handleEditAppointment = useCallback((appointment) => {
        setEditingAppointment(appointment);
        const response = updateAppointment(appointment);
        if (response) {
            console.log('Editing appointment:', appointment);
            handleScheduleSuccess();
            setMessage('Appointment updated successfully.');
            setMessageType('success');
        } else {
            console.error('Failed to edit appointment:', appointment);
        }
    }, [handleScheduleSuccess]);

    return (
        <div className="app-container">
            <nav className="main-nav">
                <div className="nav-logo">
                    Virtual Wellness App (Ruh)
                </div>
            </nav>

            <div className="main-content">
                <h1>Book Appointments</h1>

                {/* Client List Section */}
                <ClientList clients={clients} loading={loadingClients} error={errorClients} />

                {/* Upcoming Appointments Section */}
                <AppointmentList
                    allClients={clients}
                    appointments={appointments} // Pass all appointments from App state
                    loadingAppointments={loadingAppointments}
                    errorAppointments={errorAppointments}
                    onEdit={handleEditAppointment}
                    onDelete={handleDeleteAppointment}
                />

                {/* Book/Edit Appointment Section */}
                <AppointmentForm
                    clients={clients}
                    editingAppointment={editingAppointment}
                    setEditingAppointment={setEditingAppointment}
                />
            </div>

            <footer className="main-footer">
                © 2025 Virtual Wellness App. All rights reserved.
            </footer>
        </div>
    );
};

export default App;
